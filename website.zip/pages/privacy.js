import React from "react";

export default function privacy() {
  return <div>privacy</div>;
}
