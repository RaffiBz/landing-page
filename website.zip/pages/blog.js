import React from "react";

export default function blog() {
  return <div>blog</div>;
}
