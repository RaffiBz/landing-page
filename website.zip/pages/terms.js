import React from "react";

export default function terms() {
  return <div>terms</div>;
}
