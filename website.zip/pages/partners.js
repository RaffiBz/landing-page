import React from "react";

export default function partners() {
  return <div>partners</div>;
}
