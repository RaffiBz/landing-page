import React from "react";

export default function solutions() {
  return <div>solutions</div>;
}
